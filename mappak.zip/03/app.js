"use strict";
var myself = 'pitju';
myself;
